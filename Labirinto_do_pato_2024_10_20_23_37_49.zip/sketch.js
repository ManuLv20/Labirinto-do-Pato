let x = 50;
let y = 50;
let circleSize = 20; // Tamanho do pássaro
let obstacles = []; 
let waterLilies = []; // Array para vitórias-régias
let stars = []; // Array para as estrelas
let collectedStars = 0; // Contador de estrelas coletadas
let gameWon = false; // Variável para verificar se o jogo foi ganho

// Posições dos círculos
let circles = [
  { x: 235, y: 350, size: 20, chasing: false }, // Círculo 1
  { x: 520, y: 550, size: 20, chasing: false }, // Círculo 2
  { x: 600, y: 30, size: 20, chasing: false },  // Círculo 3
  { x: 350, y: 100, size: 20, chasing: false }, // Círculo 4
  { x: 290, y: 610, size: 20, chasing: false }  // Círculo 5
];

// Array para armazenar as posições iniciais dos círculos
let initialCirclePositions = circles.map(circle => ({ ...circle }));

// Posições iniciais das estrelas
let initialStarPositions = [
  { x: 287, y: 347, size: 15 },
  { x: 600, y: 550, size: 15 },
  { x: 650, y: 30, size: 15 }
];

function setup() {
  createCanvas(690, 650);
  createMaze();
  createWaterLilies(); // Cria as vitórias-régias
  createStars(); // Cria as estrelas
}

function draw() {
  background(135, 206, 235); // Fundo azul
  
  if (gameWon) {
    displayWinMessage(); // Mostra a mensagem de vitória
  } else {
    fill("#b62b6e");
    drawBird(x, y, circleSize); // Desenha o pássaro
    moveCircle();
    checkCenter();
    drawObstacles();
    drawWaterLilies(); // Desenha as vitórias-régias
    drawStars(); // Desenha as estrelas
    drawCircles(); // Desenha os círculos
    updateCircles(); // Atualiza a posição dos círculos

    // Verifica se o pássaro colidiu com algum círculo
    for (let circle of circles) {
      if (dist(x, y, circle.x, circle.y) < (circleSize / 2 + circle.size / 2)) {
        resetGame(); // Reseta o jogo se houver colisão
      }
    }
  }
}

function createMaze() {
  obstacles.push({x: 90, y: 120, w: 20, h: 200});
  obstacles.push({x: 400, y: 50, w: 20, h: 200});
  obstacles.push({x: 206, y: 300, w: 220, h: 20});
  obstacles.push({x: 400, y: 370, w: 20, h: 220});
  obstacles.push({x: 90, y: 50, w: 400, h: 20});
  obstacles.push({x: 200, y: 200, w: 20, h: 200});
  obstacles.push({x: -10, y: -10, w: 20, h: 800});
  obstacles.push({x: 678, y: -10, w: 20, h: 800});
  obstacles.push({x: -10, y: -10, w: 800, h: 20});
  obstacles.push({x: -10, y: 630, w: 650, h: 20});
  obstacles.push({x: 550, y: 50, w: 400, h: 20});
  obstacles.push({x: 470, y: 300, w: 20, h: 400});
  obstacles.push({x: 148, y: 50, w: 10, h: 200});
  obstacles.push({x: 10, y: 310, w: 80, h: 10});
  obstacles.push({x: -40, y: 380, w: 200, h: 20});
  obstacles.push({x: 540, y: 570, w: 200, h: 20});
  obstacles.push({x: 60, y: 470, w: 200, h: 20});
  obstacles.push({x: 310, y: 300, w: 20, h: 250});
  obstacles.push({x: 50, y: 570, w: 200, h: 20});
  obstacles.push({x: 260, y: 370, w: 160, h: 10});
}

function createWaterLilies() {
  let maxLilies = 10; // Número máximo de vitórias-régias
  while (waterLilies.length < maxLilies) {
    let lily = {
      x: random(30, width - 30), // Posição aleatória dentro do canvas
      y: random(30, height - 30),
      w: 30,
      h: 10
    };
    
    // Verifica se a vitória-régia colide com algum obstáculo
    if (!collidesWithObstacles(lily)) {
      waterLilies.push(lily);
    }
  }
}

function createStars() {
  stars = initialStarPositions.map(star => ({ ...star })); // Cria as estrelas com posições iniciais
}

function collidesWithObstacles(lily) {
  for (let obs of obstacles) {
    if (lily.x + lily.w / 2 > obs.x && 
        lily.x - lily.w / 2 < obs.x + obs.w &&
        lily.y + lily.h / 2 > obs.y && 
        lily.y - lily.h / 2 < obs.y + obs.h) {
      return true; // Colidiu
    }
  }
  return false; // Não colidiu
}

function drawWaterLilies() {
  fill(0, 128, 0); // Cor verde para as vitórias-régias
  for (let lily of waterLilies) {
    ellipse(lily.x, lily.y, lily.w, lily.h); // Desenha a vitória-régia
  }
}

function drawStars() {
  fill(255, 255, 0); // Cor amarela para as estrelas
  for (let i = stars.length - 1; i >= 0; i--) {
    let star = stars[i];
    drawStar(star.x, star.y, star.size); // Desenha as estrelas
    if (dist(x, y, star.x, star.y) < circleSize / 2 + star.size / 2) {
      stars.splice(i, 1); // Remove a estrela do array
      collectedStars++; // Incrementa o contador de estrelas coletadas
    }
  }
}

function drawStar(x, y, size) {
  beginShape();
  for (let i = 0; i < 5; i++) {
    let angle = TWO_PI / 5 * i + HALF_PI; // Ângulo
    let xOffset = cos(angle) * size;
    let yOffset = sin(angle) * size;
    vertex(x + xOffset, y + yOffset);
    angle += PI / 5; // Alterna para o interior da estrela
    xOffset = cos(angle) * size / 2;
    yOffset = sin(angle) * size / 2;
    vertex(x + xOffset, y + yOffset);
  }
  endShape(CLOSE);
}

function drawObstacles() {
  fill("#366F3F"); // Cor dos obstáculos
  for (let obs of obstacles) {
    rect(obs.x, obs.y, obs.w, obs.h);
  }
}

function moveCircle() {
  let previousX = x;
  let previousY = y;

  if (keyIsDown(LEFT_ARROW)) {
    x -= 10;
  }
  if (keyIsDown(RIGHT_ARROW)) {
    x += 10;
  }
  if (keyIsDown(UP_ARROW)) {
    y -= 10;
  }
  if (keyIsDown(DOWN_ARROW)) {
    y += 10;
  }

  for (let obs of obstacles) {
    if (collides(obs)) {
      x = previousX; 
      y = previousY;
    }
  }

  // Verifica se o pássaro chegou ao final da tela
  if (y + circleSize / 2 >= height) {
    gameWon = true; // Define que o jogo foi ganho
    setTimeout(() => {
      resetGame(); // Reinicia o jogo após 5 segundos
    }, 5000);
  }
}

function collides(obs) {
  return (x + circleSize / 2 > obs.x && 
          x - circleSize / 2 < obs.x + obs.w &&
          y + circleSize / 2 > obs.y && 
          y - circleSize / 2 < obs.y + obs.h);
}

function checkCenter() {
  let canvasCenterX = width / 2;
  let canvasCenterY = height / 2;
  
  if (dist(x, y, canvasCenterX, canvasCenterY) < 10) {
    circleSize = 100; 
  } else {
    circleSize = 20; // Tamanho do pássaro ajustado para 20
  }
}

function displayWinMessage() {
  fill(0); // Cor da mensagem
  textSize(64); // Tamanho da fonte
  textAlign(CENTER, CENTER); // Centraliza o texto
  text("WIN!", width / 2, height / 2); // Mostra "WIN" no centro da tela
  textSize(32);
  text("Estrelas coletadas: " + collectedStars, width / 2, height / 2 + 50); // Mostra a quantidade de estrelas coletadas
}

function resetGame() {
  x = 50; // Reseta a posição do pássaro
  y = 50; // Reseta a posição do pássaro
  gameWon = false; // Reseta o estado do jogo
  collectedStars = 0; // Reseta o contador de estrelas coletadas
  
  // Restaura as posições iniciais dos círculos
  for (let i = 0; i < circles.length; i++) {
    circles[i] = { ...initialCirclePositions[i] };
  }

  // Restaura as estrelas para suas posições iniciais
  stars = initialStarPositions.map(star => ({ ...star }));
}

function drawBird(x, y, size) {
  // Corpo do pássaro
  fill("#ffcc00");
  ellipse(x, y, size, size / 2); // Corpo
  // Cabeça
  fill("#ffcc00");
  ellipse(x, y - size / 4, size / 2, size / 2); // Cabeça
  
  // Olhos
  fill(0); // Cor dos olhos
  ellipse(x - size / 8, y - size / 4, size / 10, size / 10); // Olho esquerdo
  ellipse(x + size / 8, y - size / 4, size / 10, size / 10); // Olho direito
  
  // Bico
  fill("#ff6600");
  triangle(x, y - size / 4, x - size / 8, y - size / 4 + size / 8, x + size / 8, y - size / 4 + size / 8); // Bico
}

function drawCircles() {
  fill("#2772CC"); // Cor azul para os círculos
  for (let circle of circles) {
    ellipse(circle.x, circle.y, circle.size, circle.size); // Desenha o círculo
  }
}

function updateCircles() {
  for (let circle of circles) {
    let distance = dist(x, y, circle.x, circle.y);
    
    // Define a distância mínima para que o círculo comece a perseguir
    if (distance < 150) {
      circle.chasing = true; // Ativa a perseguição
    }

    if (circle.chasing) {
      // Move o círculo em direção ao pássaro
      let angle = atan2(y - circle.y, x - circle.x);
      let newX = circle.x + cos(angle) * 5; // Movimento na direção do pássaro
      let newY = circle.y + sin(angle) * 5; // Movimento na direção do pássaro

      // Verifica colisão com obstáculos
      if (!checkCircleCollidesWithObstacles(newX, newY, circle.size)) {
        circle.x = newX; // Atualiza a posição se não colidir
        circle.y = newY;
      }
    }
  }
}

function checkCircleCollidesWithObstacles(circleX, circleY, circleSize) {
  for (let obs of obstacles) {
    if (circleX + circleSize / 2 > obs.x && 
        circleX - circleSize / 2 < obs.x + obs.w &&
        circleY + circleSize / 2 > obs.y && 
        circleY - circleSize / 2 < obs.y + obs.h) {
      return true; // Colidiu com o obstáculo
    }
  }
  return false; // Não colidiu
}